<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('frequencies', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->integer('value');
            $table->unsignedBigInteger('position');
            $table->enum('status',[1,2])->default(2); //1 No publicado //2 publicado
            $table->integer('score')->default(0);
            $table->unsignedBigInteger('variable_id');
            
            $table->foreign('variable_id')
                ->references('id')
                ->on('variables')
                ->onDelete('cascade')
                ->onUpdate(' cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('frequencies');
    }
};
