function sucessAlert(title = 'tarea terminada', subtitle = 'Presiona el boton para continuar'){
    Swal.fire(
        title,
        subtitle,
        'success'
    );
}