<x-app-layout>
    @livewire('line.line-show', ['line' => $line])
</x-app-layout>