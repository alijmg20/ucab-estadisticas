<x-app-layout>
    @livewire('line.line-index')
</x-app-layout>
