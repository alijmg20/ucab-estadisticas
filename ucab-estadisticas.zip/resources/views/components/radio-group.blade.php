<div {{ $attributes }}>
    {{ $slot }}
</div>