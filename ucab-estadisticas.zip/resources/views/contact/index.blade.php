<x-app-layout>
    @livewire('emails.email-index')
</x-app-layout>
