<x-app-layout>
    @livewire('front.front-graphics', ['file' => $file])
</x-app-layout>