<x-app-layout>
    @livewire('front.home-controller')
</x-app-layout>
