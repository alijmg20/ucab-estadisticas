<div>
    <x-button class="bg-green-600" wire:click.debounce.100ms="save()">Nueva</x-button>
</div>
