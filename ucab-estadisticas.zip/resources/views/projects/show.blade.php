<x-app-layout>
    @livewire('project.project-show', ['project' => $project])
</x-app-layout>