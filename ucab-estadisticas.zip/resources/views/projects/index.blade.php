<x-app-layout>
    @livewire('project.project-index')
</x-app-layout>