<x-admin-layout>
    @section('title','Administrar Experiencias')
    @livewire('testimonial.testimonial-controller')
</x-admin-layout>