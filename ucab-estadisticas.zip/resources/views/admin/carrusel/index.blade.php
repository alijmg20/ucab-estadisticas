<x-admin-layout>
    @section('title','Administrar Carrusel')
    @livewire('carrusel.carrusel-controller')      
</x-admin-layout>