<x-admin-layout>
    @section('title', 'Administrar Usuarios')
    @livewire('user.user-controller')
</x-admin-layout>