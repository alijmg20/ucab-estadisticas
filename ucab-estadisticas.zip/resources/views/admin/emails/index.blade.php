<x-admin-layout>
    @section('title','Administrar Emails')
    @livewire('emails.email-controller')      
</x-admin-layout>