<x-admin-layout>
    @section('title','Administrar Proyectos')
    @livewire('project.project-controller')
</x-admin-layout>