<x-admin-layout>
    @section('title','CER IA')
    @livewire('openai.openai-controller')
</x-admin-layout>