<x-admin-layout>
    @section('title','Administrar Lineas')
    @livewire('line.line-controller')      
</x-admin-layout>