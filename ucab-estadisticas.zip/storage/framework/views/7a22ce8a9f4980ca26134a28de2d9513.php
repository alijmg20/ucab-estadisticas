<div>
    <?php echo e($quiz); ?>

</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/answer/answer-summary.blade.php ENDPATH**/ ?>