<div>
    <div
        class="border-tab-pane-answer-top border border-gray-300 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
        <div class="px-6 py-4">
            <div class="text-sm text-gray-600 dark:text-gray-400">
                <h2 class="text-xl text-left dark:text-gray-400">
                    <?php echo e($answers->count()); ?> Respuestas
                </h2>
            </div>
        </div>
    </div>
    <div x-data="{ activeTabAnswers: 1 }">
        <div class=" mb-4 border-b border-gray-200 dark:border-gray-700">
            <ul class="border-tab-pane-answer-bottom border border-gray-300 bg-white rounded-lg overflow-hidden flex flex-wrap -mb-px text-sm font-medium text-center justify-around">
                <li wire:click="updateTab(1)" class="mr-2" role="presentation">
                    <a x-on:click.prevent="activeTabAnswers = 1"
                        :class="{
                            'inline-block p-4 border-b-2 rounded-t-lg text-blue-600 hover:text-blue-600 dark:text-blue-500 dark:hover:text-blue-500 border-blue-600 dark:border-blue-500': activeTabAnswers ===
                                1,
                            'inline-block p-4 border-b-2 border-transparent rounded-t-lg dark:border-transparent text-gray-500 hover:text-gray-600 dark:text-gray-400 border-gray-100 hover:border-gray-300 dark:border-gray-700 dark:hover:text-gray-300': activeTabAnswers !==
                                1
                        }"
                        href="#">Resumen</a>
                </li>
                <li wire:click="updateTab(2)" class="mr-2" role="presentation">
                    <a x-on:click.prevent="activeTabAnswers = 2"
                        :class="{
                            'inline-block p-4 border-b-2 rounded-t-lg text-blue-600 hover:text-blue-600 dark:text-blue-500 dark:hover:text-blue-500 border-blue-600 dark:border-blue-500': activeTabAnswers ===
                                2,
                            'inline-block p-4 border-b-2 border-transparent rounded-t-lg dark:border-transparent text-gray-500 hover:text-gray-600 dark:text-gray-400 border-gray-100 hover:border-gray-300 dark:border-gray-700 dark:hover:text-gray-300': activeTabAnswers !==
                                2
                        }"
                        href="#">Preguntas</a>
                </li>
                <li wire:click="updateTab(3)" class="mr-2" role="presentation">
                    <a x-on:click.prevent="activeTabAnswers = 3"
                        :class="{
                            'inline-block p-4 border-b-2 rounded-t-lg text-blue-600 hover:text-blue-600 dark:text-blue-500 dark:hover:text-blue-500 border-blue-600 dark:border-blue-500': activeTabAnswers ===
                                3,
                            'inline-block p-4 border-b-2 border-transparent rounded-t-lg dark:border-transparent text-gray-500 hover:text-gray-600 dark:text-gray-400 border-gray-100 hover:border-gray-300 dark:border-gray-700 dark:hover:text-gray-300': activeTabAnswers !==
                                3
                        }"
                        href="#">Individual</a>
                </li>
            </ul>
        </div>
        <div>
            <div x-show="activeTabAnswers === 1">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.summary.answer-summary', ['quiz' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('l2809460706-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2809460706-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2809460706-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2809460706-0');
} else {
    $response = \Livewire\Livewire::mount('answer.summary.answer-summary', ['quiz' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l2809460706-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div x-show="activeTabAnswers === 2">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.question.answer-question', ['quiz' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('l2809460706-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2809460706-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2809460706-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2809460706-1');
} else {
    $response = \Livewire\Livewire::mount('answer.question.answer-question', ['quiz' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l2809460706-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div x-show="activeTabAnswers === 3">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.individual.answer-individual', ['quiz' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('l2809460706-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l2809460706-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2809460706-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2809460706-2');
} else {
    $response = \Livewire\Livewire::mount('answer.individual.answer-individual', ['quiz' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l2809460706-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/answer/answer-controller.blade.php ENDPATH**/ ?>