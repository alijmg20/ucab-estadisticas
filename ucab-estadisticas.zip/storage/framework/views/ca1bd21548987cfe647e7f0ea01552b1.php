<?php if (isset($component)) { $__componentOriginal7eabf39aae4b967e7b450e91334b1e2d = $component; } ?>
<?php $component = App\View\Components\QuizLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('quiz-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\QuizLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title','Responder Encuesta'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.answer-quiz', ['quiz' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('58Scg9R')) {
    $componentId = $_instance->getRenderedChildComponentId('58Scg9R');
    $componentTag = $_instance->getRenderedChildComponentTagName('58Scg9R');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('58Scg9R');
} else {
    $response = \Livewire\Livewire::mount('answer.answer-quiz', ['quiz' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('58Scg9R', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7eabf39aae4b967e7b450e91334b1e2d)): ?>
<?php $component = $__componentOriginal7eabf39aae4b967e7b450e91334b1e2d; ?>
<?php unset($__componentOriginal7eabf39aae4b967e7b450e91334b1e2d); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/answer/index.blade.php ENDPATH**/ ?>