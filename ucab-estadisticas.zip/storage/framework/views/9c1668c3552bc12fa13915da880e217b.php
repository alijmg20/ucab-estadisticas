<div wire:init='loadgraphic'>
    <div class="container mx-auto px-8 sm:px-8">
        <h1 class="mt-4 text-3xl text-center dark:text-gray-400">
            #<?php echo e($file->id); ?> <?php echo e($file->name); ?>

        </h1>
    </div>
    <div id="graphics-show" class="px-6 py-6">
        <?php if(count($variablesActive)): ?>
            <div class="grid grid-cols-3 gap-4 font-mono text-white text-sm text-center font-bold leading-6">
                <?php $__currentLoopData = $variablesActive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variableActive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-graphic', ['variable' => $variableActive['id'], 'selection' => random_int(1, 6)])->html();
} elseif ($_instance->childHasBeenRendered($variableActive['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($variableActive['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($variableActive['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variableActive['id']);
} else {
    $response = \Livewire\Livewire::mount('front.front-graphic', ['variable' => $variableActive['id'], 'selection' => random_int(1, 6)]);
    $html = $response->html();
    $_instance->logRenderedChild($variableActive['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-graphic', ['variable' => 0, 'selection' => random_int(1, 6)])->html();
} elseif ($_instance->childHasBeenRendered('l191492625-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l191492625-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l191492625-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l191492625-1');
} else {
    $response = \Livewire\Livewire::mount('front.front-graphic', ['variable' => 0, 'selection' => random_int(1, 6)]);
    $html = $response->html();
    $_instance->logRenderedChild('l191492625-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
            <div class="container mt-4 mb-4">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-loading-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-loading-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('title', null, []); ?> NO se muestran variables seleccionadas <?php $__env->endSlot(); ?>
                     <?php $__env->slot('subtitle', null, []); ?> ¡las variables No estan disponibles!
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/front/front-graphics.blade.php ENDPATH**/ ?>