<?php if (isset($component)) { $__componentOriginal7eabf39aae4b967e7b450e91334b1e2d = $component; } ?>
<?php $component = App\View\Components\QuizLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('quiz-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\QuizLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title','Encuesta Respondida'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.answered', ['quiz' => $quiz->id])->html();
} elseif ($_instance->childHasBeenRendered('QJDoJbX')) {
    $componentId = $_instance->getRenderedChildComponentId('QJDoJbX');
    $componentTag = $_instance->getRenderedChildComponentTagName('QJDoJbX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QJDoJbX');
} else {
    $response = \Livewire\Livewire::mount('answer.answered', ['quiz' => $quiz->id]);
    $html = $response->html();
    $_instance->logRenderedChild('QJDoJbX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7eabf39aae4b967e7b450e91334b1e2d)): ?>
<?php $component = $__componentOriginal7eabf39aae4b967e7b450e91334b1e2d; ?>
<?php unset($__componentOriginal7eabf39aae4b967e7b450e91334b1e2d); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/answer/answered.blade.php ENDPATH**/ ?>