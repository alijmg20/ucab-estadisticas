<div class="">
    <?php $__env->startSection('title', $title); ?>
    <div class="pb-4 mx-auto px-8 sm:px-8 flex items-center">

        <h1 class="justify-center inline-block w-full flex mt-4 text-3xl text-center dark:text-gray-400 ml-4 mr-4">
            <span class="ml-4">
                Reporte de <?php echo e($file->name); ?>

            </span>
            <a class="ml-4 disabled:opacity-25 inline-flex items-center px-4 py-2 bg-gray-800 dark:bg-gray-200 border border-transparent rounded-md font-semibold text-xs text-white dark:text-gray-800 uppercase tracking-widest hover:bg-gray-700 dark:hover:bg-white focus:bg-gray-700 dark:focus:bg-white active:bg-gray-900 dark:active:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150"
                id="btnPrint" href="#">descargar PDF</a>
        </h1>
    </div>
    <div class="mt-4 container" id="content">
        <?php if(count($variablesActive) || count($correlations)): ?>
            <?php $__currentLoopData = $variablesActive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variableActive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php switch($variableActive['variabletype_id']):
                    case (1): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.qualitatives.variable-qualitative', ['variable' => $variableActive['id']])->html();
} elseif ($_instance->childHasBeenRendered($variableActive['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($variableActive['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($variableActive['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variableActive['id']);
} else {
    $response = \Livewire\Livewire::mount('graphics.qualitatives.variable-qualitative', ['variable' => $variableActive['id']]);
    $html = $response->html();
    $_instance->logRenderedChild($variableActive['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php break; ?>

                    <?php case (2): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.multiple.graphic', ['variable' => $variableActive['id']])->html();
} elseif ($_instance->childHasBeenRendered($variableActive['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($variableActive['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($variableActive['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variableActive['id']);
} else {
    $response = \Livewire\Livewire::mount('graphics.multiple.graphic', ['variable' => $variableActive['id']]);
    $html = $response->html();
    $_instance->logRenderedChild($variableActive['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php break; ?>

                    <?php case (3): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => $variableActive['id']])->html();
} elseif ($_instance->childHasBeenRendered($variableActive['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($variableActive['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($variableActive['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variableActive['id']);
} else {
    $response = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => $variableActive['id']]);
    $html = $response->html();
    $_instance->logRenderedChild($variableActive['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php break; ?>
                <?php endswitch; ?>
                <div style="page-break-before: always;"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($correlations)): ?>
                <?php $__currentLoopData = $correlations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $correlation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => $correlation['id']])->html();
} elseif ($_instance->childHasBeenRendered($correlation['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($correlation['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($correlation['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($correlation['id']);
} else {
    $response = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => $correlation['id']]);
    $html = $response->html();
    $_instance->logRenderedChild($correlation['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php if($key < count($correlations) - 1): ?>
                        <div style="page-break-before: always;"></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php else: ?>
            <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.qualitatives.variable-qualitative', ['variable' => 0])->html();
} elseif ($_instance->childHasBeenRendered('l2570818823-4')) {
    $componentId = $_instance->getRenderedChildComponentId('l2570818823-4');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2570818823-4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2570818823-4');
} else {
    $response = \Livewire\Livewire::mount('graphics.qualitatives.variable-qualitative', ['variable' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('l2570818823-4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
            <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.multiple.graphic', ['variable' => 0])->html();
} elseif ($_instance->childHasBeenRendered('l2570818823-5')) {
    $componentId = $_instance->getRenderedChildComponentId('l2570818823-5');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2570818823-5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2570818823-5');
} else {
    $response = \Livewire\Livewire::mount('graphics.multiple.graphic', ['variable' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('l2570818823-5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
            <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => 0])->html();
} elseif ($_instance->childHasBeenRendered('l2570818823-6')) {
    $componentId = $_instance->getRenderedChildComponentId('l2570818823-6');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2570818823-6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2570818823-6');
} else {
    $response = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('l2570818823-6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
            <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => 0])->html();
} elseif ($_instance->childHasBeenRendered('l2570818823-7')) {
    $componentId = $_instance->getRenderedChildComponentId('l2570818823-7');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2570818823-7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2570818823-7');
} else {
    $response = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('l2570818823-7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
            <div class="container mt-4 mb-4">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-loading-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-loading-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('title', null, []); ?> Variables NO seleccionadas <?php $__env->endSlot(); ?>
                     <?php $__env->slot('subtitle', null, []); ?> ¡Debe seleccionar las variables que desea ver en la pestaña
                        <b>variables!</b>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <script>
        document.addEventListener('livewire:load', function() {
        });
        document.getElementById('btnPrint').addEventListener('click', function() {
            $("#btnPrint").css('display', 'none');
            window.print();
            $("#btnPrint").css('display', 'inline-flex');
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/pdf/pdf.blade.php ENDPATH**/ ?>