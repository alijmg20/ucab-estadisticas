<div>
    <?php if($question->typequestion == 1): ?>
    <div
        class="border border-gray-300 mb-6 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
        <div class="px-6 py-4">
            <?php echo e($question->name); ?>

        </div>
        <div class="w-full form-control input-quiz border rounded-md p-2 overflow-hidden text-3xl">
            <?php echo e($answer->answer); ?>

        </div>
    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/answer/individual/answer-individual-question.blade.php ENDPATH**/ ?>