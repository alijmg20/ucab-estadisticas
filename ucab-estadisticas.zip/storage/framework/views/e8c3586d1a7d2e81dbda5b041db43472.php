<div>
    <h1 class="mt-4 text-center text-2xl text-slate-800 font-bold mb-4"><?php echo e(__('Bienvenido Investigador!')); ?> <i
            class="fas fa-search"></i></h1>

    <div class="space-y-4">
        <div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'email','value' => ''.e(__('Correo')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','value' => ''.e(__('Correo')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <input
                class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm w-full"
                id="password" type="email" wire:model.defer="email" placeholder="correo..."
                wire:keydown.enter="login()">
        </div>
        <div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'password','value' => ''.e(__('Clave')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','value' => ''.e(__('Clave')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <input
                class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm w-full"
                id="password" type="<?php echo e($type_pass); ?>" wire:model.defer="password" placeholder="Contraseña..."
                wire:keydown.enter="login()" required="required" autocomplete="current-password">
        </div>
    </div>
    <div class="flex items-center justify-between mt-6">

        <div class="form-group clearfix">
            <label class="fancy-checkbox element-left">
                <input wire:click="showHidePass()" type="checkbox"<?php if($type_pass == 'text'): ?> checked <?php endif; ?>>
                <span>Ver contraseña</span>
            </label>
        </div>
        <button wire:click="login()" wire:loading.attr="disabled"
            class="rounded w-full p-2 text-indigo-100 bg-indigo-500 hover:bg-indigo-700">
            <span wire:loading.remove>Iniciar Sesion</span>

            <span wire:loading>
                <span class="loading_p spinner-border spinner-border-sm" role="status"
                    style="font-size:8px; display:block; margin:auto;">
                    <span class="sr-only"></span>
                </span>
            </span>
        </button>
    </div>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mt-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <div class="pt-5 mt-6 border-t border-slate-200">
        <div class="text-sm">
            <?php echo e(__('¿Aun no tienes una cuenta?')); ?> <a class="font-medium text-indigo-500 hover:text-indigo-600"
                href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarse')); ?></a>
        </div>
        <!-- Warning -->
        
    </div>

    <script>

        document.addEventListener('livewire:load', function() {
            Livewire.on('login_fail', i => {
                toastRight('warning', 'Contraseña incorecta!');
            });
            Livewire.on('no_register', i => {
                toastRight('warning', 'El CORREO ingresado no se encuentra registrado!');
            });
            Livewire.on('user_no_verificado', i => {
                alertMessage('No se ha confirmado el correo!!',
                    'Lo sentimos, el correo ingresado no ha sido validado, por favor revise su bandeja de entrada, a veces por accidente cae en SPAM, confirme su registro para poder acceder al sistema.',
                    'warning')
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/auth/login-propio.blade.php ENDPATH**/ ?>