<div>
    <?php if($questions): ?>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
            class="border border-gray-300 mb-6 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
            <div class="px-6 py-4">
                <div class="text-sm text-gray-600 dark:text-gray-400">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.summary.summary-graphic', ['question' => $question->id])->html();
} elseif ($_instance->childHasBeenRendered($question->id)) {
    $componentId = $_instance->getRenderedChildComponentId($question->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($question->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($question->id);
} else {
    $response = \Livewire\Livewire::mount('answer.summary.summary-graphic', ['question' => $question->id]);
    $html = $response->html();
    $_instance->logRenderedChild($question->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('answer.summary.summary-graphic', ['question' => 0])->html();
} elseif ($_instance->childHasBeenRendered($question->id)) {
    $componentId = $_instance->getRenderedChildComponentId($question->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($question->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($question->id);
} else {
    $response = \Livewire\Livewire::mount('answer.summary.summary-graphic', ['question' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild($question->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/answer/summary/answer-summary.blade.php ENDPATH**/ ?>