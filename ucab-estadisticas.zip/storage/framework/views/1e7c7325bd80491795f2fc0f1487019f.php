<div wire:init='loadgraphicvariables'>
    <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4">
        <div class="bg-white w-full shadow rounded-lg p-3">
            <div class="grid grid-cols-2 md:grid-cols-3">
                <?php $__currentLoopData = $variables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="variable-<?php echo e($variable->id); ?>"class="hover:bg-gray-300 rounded-md hover:shadow-lg border border-gray-100">
                        <div class="flex  p-2 justify-between">
                            <div>
                                <input id="default-checkbox-<?php echo e($variable->id); ?>" type="checkbox" value="" <?php if($variable->status == 2): ?> checked <?php endif; ?> wire:click="status(<?php echo e($variable->id); ?>)" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                <label for="default-checkbox-<?php echo e($variable->id); ?>" class="ml-2 text-sm text-left font-medium text-gray-900  dark:text-gray-300"><?php echo e($variable->name); ?></label>
                            </div>
                            <div class="flex items-right text-sm">
                                <button wire:click='$emitTo("variable.variable-modal","edit",<?php echo e($variable->id); ?>)'
                                    class="flex mr-2 items-center  text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                    aria-label="Edit">
                                    <i class="fas fa-pencil-alt"></i>
                                </button>
                                <button wire:click='$emit("variableDelete",<?php echo e($variable->id); ?>)'
                                    class="flex items-center  text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                    aria-label="Delete">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('variable.variable-modal')->html();
} elseif ($_instance->childHasBeenRendered('l2973315205-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2973315205-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2973315205-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2973315205-0');
} else {
    $response = \Livewire\Livewire::mount('variable.variable-modal');
    $html = $response->html();
    $_instance->logRenderedChild('l2973315205-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('groupAlert', (title, message) => {
                alert(title, message)
            });
            Livewire.on('groupDelete', (group) => {
                Swal.fire({
                    title: '¿Estas seguro?',
                    text: "¡Esta acción es irreversible!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, estoy seguro!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.emitTo("groups.group-controller", "delete", group);
                        Swal.fire(
                            'Eliminado!',
                            "Se ha sido eliminado.",
                            'success'
                        )
                    }
                })
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/graphic-variables.blade.php ENDPATH**/ ?>