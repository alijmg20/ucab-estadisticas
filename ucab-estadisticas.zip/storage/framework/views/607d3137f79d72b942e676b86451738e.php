<div <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/components/radio-group.blade.php ENDPATH**/ ?>