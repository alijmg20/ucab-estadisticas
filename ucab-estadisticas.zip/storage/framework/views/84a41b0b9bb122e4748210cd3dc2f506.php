<div wire:init='loadWordCloud'>
    <?php if($variable): ?>
        <div
            class="border border-gray-300 mb-6 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
            <div class="px-6 py-4">
                <div id="qualitative-<?php echo e($variable->id); ?>"></div>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.qualitatives.qualitative-table',['variable' => $variable->id])->html();
} elseif ($_instance->childHasBeenRendered('l1377665688-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1377665688-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1377665688-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1377665688-0');
} else {
    $response = \Livewire\Livewire::mount('graphics.qualitatives.qualitative-table',['variable' => $variable->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l1377665688-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    <?php endif; ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('cloudShow', (data,variable) => {
                // Datos para la nube de palabras
                name = "qualitative-" + variable.id;
                generateWordCloud(data,name,variable);
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/qualitatives/variable-qualitative.blade.php ENDPATH**/ ?>