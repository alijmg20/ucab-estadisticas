<select <?php echo $attributes->merge(['class' => 'block  mt-1 rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50']); ?>>
    <?php echo e($slot); ?>

</select><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/components/select-dropdown.blade.php ENDPATH**/ ?>