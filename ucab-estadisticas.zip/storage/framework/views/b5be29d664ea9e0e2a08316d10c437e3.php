<div wire:init='loadQuestionsQuizzes()'>
    <?php if($questions && !count($questions)): ?>
        <div>No hay preguntas creadas</div>
    <?php elseif($questions && count($questions)): ?>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('questions.question', ['question' => $question->id])->html();
} elseif ($_instance->childHasBeenRendered($question->id)) {
    $componentId = $_instance->getRenderedChildComponentId($question->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($question->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($question->id);
} else {
    $response = \Livewire\Livewire::mount('questions.question', ['question' => $question->id]);
    $html = $response->html();
    $_instance->logRenderedChild($question->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div>Cargando encuesta...</div>
    <?php endif; ?>

    <?php echo $__env->make('livewire.questions._partials.add-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('questionAlert', (type, message) => {
                toastRight(type, message)
            });
            Livewire.on('questionDelete', (type, message) => {
                toastRight(type, message)
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/questions/questions-quiz.blade.php ENDPATH**/ ?>