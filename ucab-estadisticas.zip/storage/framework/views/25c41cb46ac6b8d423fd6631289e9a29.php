<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="shortcut icon"  type="image/png" href="<?php echo e(asset('/img/logos/favicon.png')); ?>">
        <title><?php echo e(config('app.name', 'Iniciar Sesion')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <link rel="stylesheet" href="<?php echo e(asset('vendor/toastr/toastr.min.css')); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="font-inter antialiased bg-slate-100 text-slate-600">

        <main class="bg-white">

            <div class="relative flex">

                <!-- Content -->
                <div class="w-full">

                    <style>
                        .background-image {
                            background-size: cover;
                            background-position: center center;
                        }
                        
                        .content-shadow {
                            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.4);
                            border-radius: 0.5rem;
                        }
                    </style>

                    <div style="background-image: url(<?php echo e(asset('/img/login/imagenfondo.png')); ?>);" class="min-h-screen h-full flex flex-col after:flex-1 background-image">

                        <!-- Header -->
                        <div class="flex-1">
                            <div class="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8">
                                <!-- Logo -->
                                <a class="block" href="/">
                                    <figure>
                                        
                                    </figure>
                                </a>
                            </div>
                        </div>
                    
                        <div class="w-full max-w-md mx-auto px-4 py-8 content-shadow bg-white">
                        
                            <a href="/">
                                <div class="mx-auto">
                                    <img src="<?php echo e(asset('img/logos/LogoUCAB.png')); ?>" alt="Logo de la empresa" class="w-16rem mx-auto">
                                </div>
                            </a>

                           <?php if(isset($slot)): ?>
                           <?php echo e($slot); ?>

                               
                           <?php else: ?>
                            <?php echo $__env->yieldContent('content'); ?>
                           <?php endif; ?> 
                        
                        </div>
                    
                    </div>

                </div>

                <!-- Image -->
                

            </div>

        </main>   
        <script src="<?php echo e(asset('js/show_alerts.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/toastr/toastr.js')); ?>"></script>
        <?php echo \Livewire\Livewire::scripts(); ?>     
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/layouts/authentication.blade.php ENDPATH**/ ?>