
<?php $__env->startSection('title', 'Clic Cloud | Login'); ?>


<?php $__env->startSection('content'); ?>
    <style>
        body{
            background: #22252A;
        }
    </style>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login-propio')->html();
} elseif ($_instance->childHasBeenRendered('kDnPyCM')) {
    $componentId = $_instance->getRenderedChildComponentId('kDnPyCM');
    $componentTag = $_instance->getRenderedChildComponentTagName('kDnPyCM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kDnPyCM');
} else {
    $response = \Livewire\Livewire::mount('auth.login-propio');
    $html = $response->html();
    $_instance->logRenderedChild('kDnPyCM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/auth/login.blade.php ENDPATH**/ ?>