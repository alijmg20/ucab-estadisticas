
<?php $__env->startSection('title', 'Clic Cloud | Login'); ?>


<?php $__env->startSection('content'); ?>
    <style>
        body{
            background: #22252A;
        }
    </style>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login-propio')->html();
} elseif ($_instance->childHasBeenRendered('fa8B3qf')) {
    $componentId = $_instance->getRenderedChildComponentId('fa8B3qf');
    $componentTag = $_instance->getRenderedChildComponentTagName('fa8B3qf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fa8B3qf');
} else {
    $response = \Livewire\Livewire::mount('auth.login-propio');
    $html = $response->html();
    $_instance->logRenderedChild('fa8B3qf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/auth/login.blade.php ENDPATH**/ ?>