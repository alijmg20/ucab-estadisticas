
<?php $__env->startSection('title', 'Clic Cloud | Login'); ?>


<?php $__env->startSection('content'); ?>
    <style>
        body{
            background: #22252A;
        }
    </style>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login-propio')->html();
} elseif ($_instance->childHasBeenRendered('h9hbzfh')) {
    $componentId = $_instance->getRenderedChildComponentId('h9hbzfh');
    $componentTag = $_instance->getRenderedChildComponentTagName('h9hbzfh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h9hbzfh');
} else {
    $response = \Livewire\Livewire::mount('auth.login-propio');
    $html = $response->html();
    $_instance->logRenderedChild('h9hbzfh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/auth/login.blade.php ENDPATH**/ ?>