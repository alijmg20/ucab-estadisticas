<div>
    <div class="inline-block w-full bg-white shadow rounded-lg overflow-hidden">
        <div class="px-6 py-4 flex flex-items-center">
            <div class="flex items-center">
                <span class="mr-2 text-gray-700 dark:text-gray-400">Mostrar</span>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select-dropdown','data' => ['class' => 'mx-2','wire:model.def' => 'cantCorrelation']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mx-2','wire:model.def' => 'cantCorrelation']); ?>
                    <?php $__currentLoopData = $entrysCorrelation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($entry); ?>"><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <option value="">selecciona una opcion</option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <span class="ml-2 mr-2 text-gray-700 dark:text-gray-400">Entradas</span>
            </div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => 'Buscar','class' => 'flex-1 mr-4','wire:model' => 'searchCorrelation','type' => 'text']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Buscar','class' => 'flex-1 mr-4','wire:model' => 'searchCorrelation','type' => 'text']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.correlation.correlation-modal',['file' => $file->id])->html();
} elseif ($_instance->childHasBeenRendered('l4147065081-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4147065081-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4147065081-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4147065081-0');
} else {
    $response = \Livewire\Livewire::mount('graphics.correlation.correlation-modal',['file' => $file->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l4147065081-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <?php if($correlations && count($correlations) && $correlations->hasPages()): ?>
            <div class="px-6 py-3">
                <?php echo e($correlations->links()); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php if(count($correlations)): ?>
        <?php $__currentLoopData = $correlations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correlation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => $correlation['id']])->html();
} elseif ($_instance->childHasBeenRendered($correlation['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($correlation['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($correlation['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($correlation['id']);
} else {
    $response = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => $correlation['id']]);
    $html = $response->html();
    $_instance->logRenderedChild($correlation['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <?php else: ?>
        <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => 0])->html();
} elseif ($_instance->childHasBeenRendered('l4147065081-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l4147065081-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4147065081-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4147065081-2');
} else {
    $response = \Livewire\Livewire::mount('graphics.correlation.variable-correlation', ['correlation' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('l4147065081-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
        <div class="container mt-4 mb-4">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-loading-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-loading-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> NO existen correlaciones <?php $__env->endSlot(); ?>
                 <?php $__env->slot('subtitle', null, []); ?> ¡Puede crear una en el botón 
                    <b>NUEVA</b>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    <?php endif; ?>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('correlationAlert', (title, message) => {
                alert(title, message)
            });
            Livewire.on('correlationDelete', (correlation) => {
                Swal.fire({
                    title: '¿Estas seguro?',
                    text: "¡Esta acción es irreversible!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, estoy seguro!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.emitTo("graphics.correlation.correlation-controller", "delete",
                            correlation);
                        Swal.fire(
                            'Eliminado!',
                            "Se ha sido eliminado.",
                            'success'
                        )
                    }
                })
            });
        }); 
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/correlation/correlation-controller.blade.php ENDPATH**/ ?>