<div>
    <div class="px-6 py-4">
        <div
            class="text-2xl text-left dark:text-gray-400 flex items-center justify-between w-full p-5 
        font-medium text-left text-gray-800  focus:outline-none">
            Cuadro de variable
        </div>
        <div class="inline-flex w-full justify-center gap-6 mb-8">
            <!-- Card -->
            <div class=" p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
                <div class="container mt-4">
                    <p class="mb-2 text-md font-medium text-gray-600 dark:text-gray-400">
                        Frecuencias de palabras
                    </p>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('headers', null, []); ?> 
                            <th class="px-4 py-3">
                                Nombre
                            </th>
                            <th class="px-4 py-3">
                                frecuencia
                            </th>
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('body', null, []); ?> 
                            <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600">
                                    <td class="px-6 py-3 text-sm">
                                        <?php echo e($word->name); ?>

                                    </td>
                                    <td class="px-4 py-3">
                                        <?php echo e($word->value); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if(count($words) && $words->hasPages()): ?>
                        <div class="mt-4 px-6 py-3">
                            <?php echo e($words->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="container mt-4">
                    <p class="mb-2 text-md font-medium text-gray-600 dark:text-gray-400">
                        Analisis de sentimiento de la variable
                    </p>
                    <div class="inline-flex gap-6 mb-8">
                        <!-- Card -->
                        <div class="flex items-center p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
                            <div class="p-3 mr-4 rounded-full">
                                <i class="fas fa-smile text-3xl text-green-500"></i>
                            </div>
                            <div>
                                <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                                    Impacto Positivo
                                </p>
                                <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">
                                    <?php echo e($sensibility['positive']); ?> %
                                </p>
                            </div>
                        </div>
                        <!-- Card -->
                        <div class="flex items-center p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
                            <div class="p-3 mr-4 rounded-full">
                                <i class="fas fa-frown text-3xl text-red-500"></i>
                            </div>
                            <div>
                                <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                                    Impacto Negativo
                                </p>
                                <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">
                                    <?php echo e($sensibility['negative']); ?> %
                                </p>
                            </div>
                        </div>
                        <!-- Card -->
                        <div class="flex items-center p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
                            <div class="p-3 mr-4 rounded-full">
                                <i class="fas fa-meh text-3xl text-gray-400"></i>
                            </div>
                            <div>
                                <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                                    Impacto Neutral
                                </p>
                                <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">
                                    <?php echo e($sensibility['neutral']); ?> %
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/qualitatives/qualitative-table.blade.php ENDPATH**/ ?>