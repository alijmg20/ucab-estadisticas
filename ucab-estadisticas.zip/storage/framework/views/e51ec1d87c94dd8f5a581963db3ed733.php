<div wire:init='loadfileshow'>
    <div class="pb-4 container mx-auto px-8 sm:px-8 flex items-center">
        
        <h1 class="inline-block w-full flex mt-4 text-3xl text-left dark:text-gray-400 ml-4 mr-4">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'back()','class' => 'bg-blue-500 disabled:opacity-25']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'back()','class' => 'bg-blue-500 disabled:opacity-25']); ?>
                volver
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <span class="ml-4">
                Datos de <?php echo e($file->name); ?>

            </span>
        </h1>
    </div>
    <div x-data="{ activeTab: 1 }" class="container mx-auto px-4 sm:px-8">
        <ul
            class="hidden text-sm font-medium text-center text-gray-500 divide-x divide-gray-200 rounded-lg shadow sm:flex dark:divide-gray-700 dark:text-gray-400">
            <li wire:click="$set('content',1)" class="w-full">
                <a x-on:click.prevent="activeTab = 1"
                    :class="{
                        'inline-block w-full p-4 text-gray-900 bg-gray-100 rounded-l-lg active focus:outline-none dark:bg-gray-700 dark:text-white': activeTab ===
                            1,
                        'inline-block w-full p-4 bg-white hover:text-gray-700 hover:bg-gray-50 focus:outline-none dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700': activeTab !==
                            1
                    }"
                    href="#">Tabla</a>
            </li>
            <li wire:click="$set('content',2)" class="w-full">
                <a x-on:click.prevent="activeTab = 2"
                    :class="{
                        'inline-block w-full p-4 text-gray-900 bg-gray-100 rounded-l-lg active focus:outline-none dark:bg-gray-700 dark:text-white': activeTab ===
                            2,
                        'inline-block w-full p-4 bg-white hover:text-gray-700 hover:bg-gray-50 focus:outline-none dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700': activeTab !==
                            2
                    }"
                    href="#">Variables</a>
            </li>
            <li wire:click="$set('content',3)" class="w-full">
                <a x-on:click.prevent="activeTab = 3"
                    :class="{
                        'inline-block w-full p-4 text-gray-900 bg-gray-100 rounded-l-lg active focus:outline-none dark:bg-gray-700 dark:text-white': activeTab ===
                            3,
                        'inline-block w-full p-4 bg-white hover:text-gray-700 hover:bg-gray-50 focus:outline-none dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700': activeTab !==
                            3
                    }"
                    href="#">General</a>
            </li>
            <li wire:click="$set('content',4)" class="w-full">
                <a x-on:click.prevent="activeTab = 4"
                    :class="{
                        'inline-block w-full p-4 text-gray-900 bg-gray-100 rounded-l-lg active focus:outline-none dark:bg-gray-700 dark:text-white': activeTab ===
                            4,
                        'inline-block w-full p-4 bg-white hover:text-gray-700 hover:bg-gray-50 focus:outline-none dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700': activeTab !==
                            4
                    }"
                    href="#">Detalles</a>
            </li>
        </ul>

        <div>
            <div x-show="activeTab === 1"><?php echo $__env->make('livewire.file._partials.fileTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="mt-4 mb-4" x-show="activeTab === 2"> 
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('variable.variable-controller', ['file' => $file])->html();
} elseif ($_instance->childHasBeenRendered('l910508151-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l910508151-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l910508151-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l910508151-0');
} else {
    $response = \Livewire\Livewire::mount('variable.variable-controller', ['file' => $file]);
    $html = $response->html();
    $_instance->logRenderedChild('l910508151-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div class="mt-4 mb-4" x-show="activeTab === 3"> <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.graphic-controller', ['file' => $file])->html();
} elseif ($_instance->childHasBeenRendered('l910508151-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l910508151-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l910508151-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l910508151-1');
} else {
    $response = \Livewire\Livewire::mount('graphics.graphic-controller', ['file' => $file]);
    $html = $response->html();
    $_instance->logRenderedChild('l910508151-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  </div>
            <div class="mt-4 mb-4" x-show="activeTab === 4"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.graphic-details', ['file' => $file])->html();
} elseif ($_instance->childHasBeenRendered('l910508151-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l910508151-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l910508151-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l910508151-2');
} else {
    $response = \Livewire\Livewire::mount('graphics.graphic-details', ['file' => $file]);
    $html = $response->html();
    $_instance->logRenderedChild('l910508151-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> </div>
        </div>
    </div>

    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('variableAlert', (title, message) => {
                alert(title, message)
            });
            Livewire.on('variableDelete', (variable) => {
                Swal.fire({
                    title: '¿Estas seguro?',
                    text: "¡Esta acción es irreversible!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, estoy seguro!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.emitTo("variable.variable-controller", "delete", variable);
                        Swal.fire(
                            'Eliminado!',
                            "Se ha sido eliminado.",
                            'success'
                        )
                    }
                })
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/file/file-controller-show.blade.php ENDPATH**/ ?>