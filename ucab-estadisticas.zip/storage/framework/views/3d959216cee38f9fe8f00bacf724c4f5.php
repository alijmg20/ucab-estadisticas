<div wire:init='loadAttachment()'>
    <h2 class="mt-4 text-xl text-left dark:text-gray-400">
        Archivos adjuntos del proyecto
    </h2>
    <div class="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
        <div class="inline-block w-full shadow rounded-lg overflow-hidden">
            <div class="px-6 py-4 flex flex-items-center">
                <div class="flex items-center">
                    <span class="mr-2 text-gray-700 dark:text-gray-400">Mostrar</span>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select-dropdown','data' => ['class' => 'mx-2','wire:model.def' => 'cantAttachment']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mx-2','wire:model.def' => 'cantAttachment']); ?>
                        <?php $__currentLoopData = $entrysAttachment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($entry); ?>"><?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <span class="ml-2 mr-2 text-gray-700 dark:text-gray-400">Entradas</span>
                </div>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => 'Buscar','class' => 'flex-1 mr-4','type' => 'text','wire:model' => 'searchAttachment']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => 'Buscar','class' => 'flex-1 mr-4','type' => 'text','wire:model' => 'searchAttachment']); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('attachment.attachment-modal', ['project' => $project->id])->html();
} elseif ($_instance->childHasBeenRendered('l4090176070-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4090176070-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4090176070-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4090176070-0');
} else {
    $response = \Livewire\Livewire::mount('attachment.attachment-modal', ['project' => $project->id]);
    $html = $response->html();
    $_instance->logRenderedChild('l4090176070-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>

            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('headers', null, []); ?> 
                    <th class="cursor-pointer px-4 py-3" wire:click='order("id")'>
                        ID
                        
                        <?php if($sortAttachment == 'id'): ?>
                            <?php if($directionAttachment == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fas fa-sort float-right"></i>
                        <?php endif; ?>
                    </th>
                    <th class="cursor-pointer px-4 py-3" wire:click='order("name")'>
                        Nombre
                        
                        <?php if($sortAttachment == 'name'): ?>
                            <?php if($directionAttachment == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fas fa-sort float-right"></i>
                        <?php endif; ?>
                    </th>
                    <th class="cursor-pointer px-4 py-3" wire:click='order("status")'>
                        estado
                        
                        <?php if($sortAttachment == 'status'): ?>
                            <?php if($directionAttachment == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fas fa-sort float-right"></i>
                        <?php endif; ?>
                    </th>
                    <th class="cursor-pointer px-4 py-3" wire:click='order("ext")'>
                        Tipo de archivo
                        
                        <?php if($sortAttachment == 'ext'): ?>
                            <?php if($directionAttachment == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fas fa-sort float-right"></i>
                        <?php endif; ?>
                    </th>
                    <th class="cursor-pointer px-4 py-3" wire:click='order("created_at")'>
                        Fecha de creación
                        
                        <?php if($sortAttachment == 'created_at'): ?>
                            <?php if($directionAttachment == 'asc'): ?>
                                <i class="fas fa-sort-alpha-up-alt float-right"></i>
                            <?php else: ?>
                                <i class="fas fa-sort-alpha-down-alt float-right"></i>
                            <?php endif; ?>
                        <?php else: ?>
                            <i class="fas fa-sort float-right"></i>
                        <?php endif; ?>
                    </th>
                    <th class="px-4 py-3">
                        Acciones
                    </th>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('body', null, []); ?> 
                    <?php if($attachments && count($attachments) == 0): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center">
                                <div class="container mt-4 mb-4">
                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-loading-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-loading-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                         <?php $__env->slot('title', null, []); ?> ¡No existen archivos Adjuntos del proyecto! <?php $__env->endSlot(); ?>
                                         <?php $__env->slot('subtitle', null, []); ?> Agregue nuevos archivos adjuntos en el botón
                                            <b>NUEVA</b>
                                         <?php $__env->endSlot(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php elseif($attachments && count($attachments)): ?>
                        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr
                                class="cursor-pointer text-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-600">

                                <td class="px-6 py-3 text-sm">
                                    <a
                                        target="_blank"
                                        href="<?php echo e(App\Helpers\Tools::StorageUrl($attach->url)); ?>">
                                        <?php echo e($attach->id); ?>

                                    </a>
                                </td>
                                <td class="px-4 py-3">
                                    <a
                                        target="_blank"
                                        href="<?php echo e(App\Helpers\Tools::StorageUrl($attach->url)); ?>">
                                        <?php echo e($attach->name); ?>

                                    </a>
                                </td>
                                <td class="px-4 py-3 text-sm">
                                    <a
                                        target="_blank"
                                        href="<?php echo e(App\Helpers\Tools::StorageUrl($attach->url)); ?>">
                                        <?php echo e($attach->status == 1 ? 'No Publicado' : 'Publicado'); ?>

                                    </a>
                                </td>
                                <td class="px-6 py-3 text-sm">
                                    <a
                                        target="_blank"
                                        href="<?php echo e(App\Helpers\Tools::StorageUrl($attach->url)); ?>">
                                        <?php echo e($attach->ext); ?>

                                    </a>
                                </td>
                                <td class="px-6 py-3 text-sm">
                                    <a
                                        target="_blank"
                                        href="<?php echo e(App\Helpers\Tools::StorageUrl($attach->url)); ?>">
                                        <?php echo e($attach->created_at); ?>

                                    </a>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center space-x-4 text-sm">
                                        <a href="<?php echo e(App\Helpers\Tools::StorageUrl($attach->url)); ?>" target="_blank"
                                            class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                            aria-label="View">
                                            <i class="fas fa-download"></i>
                                        </a>
                                        <button
                                            wire:click='$emitTo("attachment.attachment-modal","edit",<?php echo e($attach->id); ?>)'
                                            class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                            aria-label="Edit">
                                            <i class="fas fa-pencil-alt"></i>
                                        </button>
                                        <button wire:click='$emit("attachmentDelete",<?php echo e($attach->id); ?>)'
                                            class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                                            aria-label="Delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center">
                                <div class="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
                                    role="status">
                                    <span
                                        class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...</span>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php if($attachments && count($attachments) && $attachments->hasPages()): ?>
                <div class="px-6 py-3">
                    <?php echo e($attachments->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('attachmentAlert', (title, message) => {
                alert(title, message)
            });
            Livewire.on('attachmentDelete', (attachment) => {
                Swal.fire({
                    title: '¿Estas seguro?',
                    text: "¡Esta acción es irreversible!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, estoy seguro!',
                    cancelButtonText: 'Cancelar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.emitTo("attachment.attachment-controller", "delete", attachment);
                        Swal.fire(
                            'Eliminado!',
                            "Se ha sido eliminado.",
                            'success'
                        )
                    }
                })
            });
        });
    </script>

</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/attachment/attachment-controller.blade.php ENDPATH**/ ?>