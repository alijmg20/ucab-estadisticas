<div <?php echo e($attributes->merge(['class' => 'bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative', 'role' => "alert"])); ?>>
    <strong class="font-bold"><?php echo e($title); ?></strong>
    <span class="block sm:inline"><?php echo e($subtitle); ?></span>
</div><?php /**PATH /home/ucabesta/public_html/resources/views/components/alert-loading-danger.blade.php ENDPATH**/ ?>