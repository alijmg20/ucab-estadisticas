<div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-carrusel')->html();
} elseif ($_instance->childHasBeenRendered('l2191819769-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2191819769-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2191819769-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2191819769-0');
} else {
    $response = \Livewire\Livewire::mount('front.front-carrusel');
    $html = $response->html();
    $_instance->logRenderedChild('l2191819769-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        
    <div id="section-information" class="container mt-4">
        <section class="bg-white dark:bg-gray-900">
            <div class="py-8 px-4 mx-auto max-w-screen-xl lg:py-16">
                <h1
                    class="mb-8 text-center text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-3xl lg:text-3xl dark:text-white">
                    ¿Que es el Centro de Estudios Regionales?</h1>
                <p class="mb-8 text-lg font-normal text-gray-500 lg:text-lg sm:px-16 lg:px-48 dark:text-gray-400">
                    El Centro de Estudios Regionales Joseph Gumilla es una organización de carácter multidisciplinario e
                    interdisciplinario, adscrito al Vicerrectorado de Extensión en Guayana y a la Facultad de Ciencias
                    Económicas y Sociales de la Universidad Católica Andrés Bello. A través de nuestras líneas de
                    investigación, estudiamos problemas relacionados con la interacción humana en espacios regional,
                    intrarregional e interregional, atendiendo criterios naturales, político-territoriales, económicos,
                    sociales, educativos y culturales.</p>

                <h1
                    class="mb-2 sm:px-16 lg:px-48 text-2xl font-bold tracking-tight leading-none text-gray-900 md:text-2xl lg:text-2xl dark:text-white">
                    Objetivo general</h1>
                <p class="mb-8 text-lg font-normal text-gray-500 lg:text-lg sm:px-16 lg:px-48 dark:text-gray-400">
                    Propiciar, promover, diseñar y coordinar líneas de investigación orientadas, fundamentalmente, al
                    estudio de problemas relacionados con la interacción humana en el espacio, cuyo carácter regional,
                    intrarregional e interregional pueda definirse atendiendo a criterios naturales,
                    político-territoriales, económicos, sociales, educativos o culturales.</p>
            </div>
        </section>
    </div>
        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-lines', 
            [
            'same' => false,
            'title' => 'Algunas de nuestras Lineas de Investigación',
            'needButton' => true,
            'titleButton' => 'Conoce Nuestras lineas de Investigación',
            ])->html();
} elseif ($_instance->childHasBeenRendered('l2191819769-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2191819769-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2191819769-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2191819769-1');
} else {
    $response = \Livewire\Livewire::mount('front.front-lines', 
            [
            'same' => false,
            'title' => 'Algunas de nuestras Lineas de Investigación',
            'needButton' => true,
            'titleButton' => 'Conoce Nuestras lineas de Investigación',
            ]);
    $html = $response->html();
    $_instance->logRenderedChild('l2191819769-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.front.front-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.front-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('url', null, []); ?> <?php echo e(asset('img/frontbanner/ucab.png')); ?> <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/front/home-controller.blade.php ENDPATH**/ ?>