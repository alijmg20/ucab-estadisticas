<div>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['maxWidth' => '8xl','id' => 'GraphicDetailsModal','wire:model' => 'open']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => '8xl','id' => 'GraphicDetailsModal','wire:model' => 'open']); ?>
         <?php $__env->slot('title', null, []); ?> 
            <div class="">
                <?php echo $variable ? '<b>' . $variable->name . '</b>' : ''; ?>

                <span wire:click='closeModal()' class="float-right text-gray-500 text-2xl cursor-pointer">&times;</span>
                <!-- Botón de cierre -->
            </div>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('content', null, []); ?> 
            <div class="mt-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-sm text-center font-bold leading-6 rounded-lg">
                    <div class="p-4 rounded-lg shadow-lg bg-white dark:text-gray-400 dark:bg-gray-800">
                        <div class="flex-none widget-header">
                            <div class="caption">
                              <p style="text-align:center"><strong>Maximo obtenido. Respuesta "<?php echo e(key($max)); ?>"</strong></p>
                            </div>
                          </div>
                        <div style="height:195.27045593261718px;" class="dark:text-gray-400 dark:bg-gray-800 widget-body flex-auto h-full w-full flex flex-col justify-center overflow-hidden">
                            <div style="font-size: 160px" class="dark:text-gray-400 dark:bg-gray-800">  <?php echo e(reset($max)); ?></div>
                        </div>
                    </div>               
                    <div class="p-4 rounded-lg shadow-lg bg-white dark:text-gray-400 dark:bg-gray-800">
                        <div class="flex-none widget-header">
                            <div class="caption">
                              <p style="text-align:center"><strong>Minimo obtenido. Respuesta "<?php echo e(key($min)); ?>"</strong></p>
                            </div>
                          </div>
                        <div style="height:195.27045593261718px;" class="dark:text-gray-400 dark:bg-gray-800 widget-body flex-auto w-full flex flex-col justify-center overflow-hidden">
                            <div style="font-size: 160px" class="dark:text-gray-400 dark:bg-gray-800">  <?php echo e(reset($min)); ?></div>
                        </div>
                    </div>     
                    
                </div>
                
                
            </div>

         <?php $__env->endSlot(); ?>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'closeModal()','class' => 'bg-blue-500 disabled:opacity-25']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'closeModal()','class' => 'bg-blue-500 disabled:opacity-25']); ?>
                <span>cerrar</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/graphic-details-modal.blade.php ENDPATH**/ ?>