<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title','Administrador de Datos'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('file.file-controller-show', ['file' => $file])->html();
} elseif ($_instance->childHasBeenRendered('zek6uvI')) {
    $componentId = $_instance->getRenderedChildComponentId('zek6uvI');
    $componentTag = $_instance->getRenderedChildComponentTagName('zek6uvI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zek6uvI');
} else {
    $response = \Livewire\Livewire::mount('file.file-controller-show', ['file' => $file]);
    $html = $response->html();
    $_instance->logRenderedChild('zek6uvI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/admin/files/showfile.blade.php ENDPATH**/ ?>