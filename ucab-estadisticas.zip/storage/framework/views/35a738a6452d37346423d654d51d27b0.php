<div <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH /home/ucabesta/public_html/resources/views/components/radio-group.blade.php ENDPATH**/ ?>