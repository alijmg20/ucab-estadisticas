<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/img/logos/favicon.png')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/tailwind.output.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/toastr/toastr.min.css')); ?>">
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
    <!-- Styles -->
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>

    <?php echo $__env->make('_partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('modals'); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/init-alpine.js')); ?>"></script>
    <script src="<?php echo e(asset('js/focus-trap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/graphics.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/toastr/toastr.js')); ?>"></script>
    <script src="<?php echo e(asset('js/show_alerts.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2@11.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/37.1.0/classic/ckeditor.js"></script>
    <script src="<?php echo e(asset('vendor/highcharts/highcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/highcharts/exporting.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/highcharts/export-data.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/highcharts/accessibility.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/layouts/admin.blade.php ENDPATH**/ ?>