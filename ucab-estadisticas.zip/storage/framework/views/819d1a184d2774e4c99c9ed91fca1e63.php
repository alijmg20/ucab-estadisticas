<div>
    <?php if(count($variablesActive)): ?>
    <?php $__currentLoopData = $variablesActive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variableActive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => $variableActive['id']])->html();
} elseif ($_instance->childHasBeenRendered($variableActive['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($variableActive['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($variableActive['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($variableActive['id']);
} else {
    $response = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => $variableActive['id']]);
    $html = $response->html();
    $_instance->logRenderedChild($variableActive['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div style="display: none"><?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => 0])->html();
} elseif ($_instance->childHasBeenRendered('l3848468065-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l3848468065-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3848468065-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3848468065-1');
} else {
    $response = \Livewire\Livewire::mount('graphics.checkbox.variable-checkbox', ['variable' => 0]);
    $html = $response->html();
    $_instance->logRenderedChild('l3848468065-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></div>
    <div class="container mt-4 mb-4">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-loading-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-loading-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('title', null, []); ?> Variables NO seleccionadas <?php $__env->endSlot(); ?>
             <?php $__env->slot('subtitle', null, []); ?> ¡Debe seleccionar las variables que desea ver en la pestaña
                <b>variables!</b>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/graphics/checkbox/checkbox-controller.blade.php ENDPATH**/ ?>