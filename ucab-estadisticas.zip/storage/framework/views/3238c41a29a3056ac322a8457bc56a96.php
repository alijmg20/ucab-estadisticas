<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1
        class="mb-8 mt-8 text-center text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-3xl lg:text-3xl dark:text-white">
        Sobre Nosotros</h1>

        <div class="container mb-8">
            <div class="flex flex-wrap items-center"> <!-- Agregando la clase 'items-center' -->
                <div class="w-full sm:w-full lg:w-3/5">
                    <img src="<?php echo e(asset('img/frontbanner/ucab.png')); ?>" alt="Foto del producto"
                        class="cursor-pointer w-full">
                </div>
                <div class="w-full sm:w-full lg:w-2/5 px-4">
                    <h1
                    class="mb-8 text-center text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-3xl lg:text-3xl dark:text-white">
                    ¿Que es el Centro de Estudios Regionales?</h1>

                    <p class="mb-4 text-lg font-normal text-gray-800 lg:text-lg dark:text-gray-400">
                        El centro de Estudios Regionales es un centro de investigación de carácter multidisciplinario e interdisciplinario, adscrito al
                        Vicerrectorado de la Extensión Guayana y a la Facultad de Ciencias Económicas y Sociales de la
                        Universidad Católica Andrés Bello.
                    </p>
                    <p class="mb-4 text-lg font-normal text-gray-800 lg:text-lg dark:text-gray-400">
                        Somos un espacio dedicado a la generación y transferencia de conocimientos orientados al estudio de
                        problemas sociales, económicos, culturales, políticos y ambientales, que impactan la vida de los
                        ciudadanos en la Región Guayana
                    </p>
                </div>
            </div>
        </div>
        

    <h1
        class="mb-4 mt-4 text-center text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-3xl lg:text-3xl dark:text-white">
        Objetivos</h1>

    <div id="section-information" class="container mt-4">
        <section class="bg-white dark:bg-gray-900">
            <div class=" px-4 mx-auto max-w-screen-xl">

                <p class="mb-4 text-lg font-normal text-gray-800 lg:text-lg sm:px-16 dark:text-gray-400">
                    Coordinar las líneas de investigación y los proyectos orientados al estudio social, económico,
                    cultural, político y ambiental de la Región Guayana.</p>

                <p class="mb-4 text-lg font-normal text-gray-800 lg:text-lg sm:px-16 dark:text-gray-400">
                    Difundir el conocimiento producido sobre el desarrollo regional mediante publicaciones, y eventos
                    académicos y no académicos.</p>

                <p class="mb-4 text-lg font-normal text-gray-800 lg:text-lg sm:px-16 dark:text-gray-400">
                    Establecer vínculos con otros centros, institutos, organismos y organizaciones nacionales e
                    internacionales, para la ejecución de proyectos en colaboración.</p>
                <p class="mb-4 text-lg font-normal text-gray-800 lg:text-lg sm:px-16 dark:text-gray-400">
                    Promover la investigación entre los estudiantes y docentes de las escuelas de pregrado y postgrado
                    de la Universidad, apoyando en los procesos investigativos.</p>
            </div>
        </section>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.front.front-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.front-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('url', null, []); ?> <?php echo e(asset('img/frontbanner/ucab.png')); ?> <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/ucabesta/public_html/resources/views/about.blade.php ENDPATH**/ ?>