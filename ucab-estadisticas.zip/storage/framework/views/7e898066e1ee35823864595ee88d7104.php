<div wire:init='loadProjectIndex'>
    
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.front.front-image','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.front-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('url', null, []); ?> <?php echo e(__('img/projects/portada.png')); ?> <?php $__env->endSlot(); ?>
         <?php $__env->slot('title', null, []); ?> <?php echo e(__('Proyectos de Investigación del Centro de Estudios Regionales')); ?> <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <div id="projects-index" class="container pb-8 ">
        <h1 class="text-2xl md:text-xl-4 font-semibold mt-4 mb-4 text-gray-600 text-center">
            <?php echo e(__('Proyectos de Investigación')); ?>

        </h1>
        <div class="px-6 pt-4 flex flex-items-center">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['placeholder' => '¿Desea buscar un proyecto?','class' => 'flex-1 mr-4','type' => 'text','wire:model' => 'search']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['placeholder' => '¿Desea buscar un proyecto?','class' => 'flex-1 mr-4','type' => 'text','wire:model' => 'search']); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
        <div class="container mx-auto">
            <?php if($projects && count($projects)): ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('projects.show', compact('project'))); ?>">
                        <div class="grid grid-cols-1 md:grid-cols-2 py-8 mt-8 mb-8 border-b border-gray-300">
                            <div class="overflow-hidden shadow-md">
                                <img src="<?php echo e(App\Helpers\Tools::StorageUrl($project->image->url)); ?>"
                                    alt="Imagen del producto" class="w-full h-auto md:h-full">
                            </div>
                            <div
                                class="rounded-md overflow-hidden shadow-md flex flex-col justify-center px-4 py-8 md:px-8 md:py-12 bg-white">
                                <div class="text-center">
                                    <h3 class="text-3xl font-bold mb-4"><?php echo e($project->name); ?></h3>
                                </div>
                                <p class="text-gray-600 text-lg mb-6 text-left truncate-2">
                                    <?php echo e(strip_tags($project->description)); ?></p>
                                <p class="text-gray-900 text-base text-left font-bold mt-4">
                                    <?php echo e(__('Encargado del proyecto: ')); ?> <?php echo e($project->user->name); ?></p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="container mx-auto mt-4 text-center">
                    <div class="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
                        role="status">
                        <span
                            class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...</span>
                    </div>
                </div>
            <?php endif; ?>
            <div class="mt-4 mb-4">
                <?php if($projects && count($projects) && $projects->hasPages()): ?>
                    <?php echo e($projects->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-testimonials')->html();
} elseif ($_instance->childHasBeenRendered('l1326473778-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1326473778-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1326473778-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1326473778-0');
} else {
    $response = \Livewire\Livewire::mount('front.front-testimonials');
    $html = $response->html();
    $_instance->logRenderedChild('l1326473778-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-lines', [
        'same' => false,
        'title' => 'Algunas de nuestras Lineas de Investigación',
        'needButton' => true,
        'titleButton' => 'Conoce Nuestras lineas de Investigación',
    ])->html();
} elseif ($_instance->childHasBeenRendered('l1326473778-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1326473778-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1326473778-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1326473778-1');
} else {
    $response = \Livewire\Livewire::mount('front.front-lines', [
        'same' => false,
        'title' => 'Algunas de nuestras Lineas de Investigación',
        'needButton' => true,
        'titleButton' => 'Conoce Nuestras lineas de Investigación',
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('l1326473778-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH /home/ucabesta/public_html/resources/views/livewire/project/project-index.blade.php ENDPATH**/ ?>