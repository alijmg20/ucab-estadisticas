<div class="container-quiz">
    <div
        class="border-gray-300 container border-t-3 border-blue-500 mt-4 mb-6 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
        <div class="px-6 py-4">
            <div class="mt-4 text-sm text-gray-600 dark:text-gray-400">
                <div class="container mt-4">
                    <div class="w-full form-control input-quiz border rounded-md p-2 overflow-hidden text-3xl">
                        <?php echo e($quiz->name); ?>

                    </div>
                </div>
                <div class="container mt-4">
                    <div class="w-full form-control input-quiz border rounded-md p-2 overflow-hidden">
                        <?php echo e($quiz->description); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($quiz->questions): ?>
        <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border border-gray-300 container mt-4 mb-6 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
                <div class="px-6 py-4">
                    <div class="mt-4 text-sm text-gray-600 dark:text-gray-400">
                        <div class="container mt-4 flex items-center">
                            <div
                                class="<?php if($question->required == 2): ?> required <?php endif; ?> w-full form-control shadow-none border-none rounded-md p-2 overflow-hidden text-xl">
                                <?php echo e($question->name); ?>

                            </div>
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'w-full','for' => 'answers.'.e($question->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','for' => 'answers.'.e($question->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                        </div>
                        <?php if($question->typequestion == 1): ?>
                            <div class="container mt-4">
                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model' => 'answers.'.e($question->id).'','placeholder' => 'Responde la pregunta aquí','id' => 'question-'.e($question->id).'','type' => 'text','class' => 'w-full input-quiz']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'answers.'.e($question->id).'','placeholder' => 'Responde la pregunta aquí','id' => 'question-'.e($question->id).'','type' => 'text','class' => 'w-full input-quiz']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                            </div>
                        <?php elseif($question->typequestion == 2): ?>
                            <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center container mt-4">
                                    <input wire:model="answers.<?php echo e($question->id); ?>"
                                        id="default-radio-<?php echo e($question->id); ?>-<?php echo e($choice->id); ?>" type="radio"
                                        value="<?php echo e($choice->value); ?>" name="question-radio-<?php echo e($question->id); ?>"
                                        class="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                    <label for="default-radio-<?php echo e($question->id); ?>-<?php echo e($choice->id); ?>"
                                        class="ml-2 dark:text-gray-300"><?php echo e($choice->value); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <div class="mb-6 rounded-lg overflow-hidden transform sm:w-full">
        <div class="flex flex-row justify-end py-4 text-right">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'submitAnswers()','wire:loading.attr' => 'disabled','wire:target' => 'submitAnswers','class' => 'bg-blue-500 disabled:opacity-25']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'submitAnswers()','wire:loading.attr' => 'disabled','wire:target' => 'submitAnswers','class' => 'bg-blue-500 disabled:opacity-25']); ?>
                Enviar
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </div>
    <script>
        document.addEventListener('livewire:load', function() {
            Livewire.on('answerQuizAlert', (title, message) => {
                alert(title, message)
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/answer/answer-quiz.blade.php ENDPATH**/ ?>