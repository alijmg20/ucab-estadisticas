<div wire:init='loadProjectShow'>
    <?php if($project->image): ?>
        <figure class="grid grid-cols-1">
            <img class="cursor-pointer object-cover object-center w-full h-auto md:h-96"
                src="<?php echo e(App\Helpers\Tools::StorageUrl($project->image->url)); ?>" alt="<?php echo e($project->name); ?>">
        </figure>
    <?php endif; ?>

    <div id="projects-show" class="container py-8">
        <h1 class="text-2xl md:text-xl-4 font-semibold mt-4 mb-4 text-gray-600 text-center">
            <?php echo e($project->name); ?>

        </h1>

        <div class="grid gap-3">
            
            <div class="mt-4 project-content sm:px-16 lg:px-48">
                <div class="project-description text-lg mb-2 mt-4">
                    <div class="description text-gray-500">
                        <?php echo $project->description; ?>

                    </div>
                </div>
            </div>
            <div class="mt-4 project-team">
                <div class="bg-white py-12 md:py-12">
                    <div class="mx-auto grid max-w-7xl gap-y-20 gap-x-8 px-6 lg:px-8 xl:grid-cols-3">
                        <div class="max-w-2xl">
                            <h2 class="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                                <?php echo e(__('Equipo del proyecto')); ?>

                            </h2>
                            <p class="mt-6 text-lg leading-8 text-gray-600">
                                <?php echo e(__('Conoce las personas participantes del proyecto')); ?></p>
                        </div>
                        <ul role="list" class="grid gap-x-8 gap-y-12 sm:grid-cols-2 sm:gap-y-16 xl:col-span-2">
                            <?php if($project->users && count($project->users)): ?>
                                <?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="flex items-center gap-x-6">
                                            <?php if($user->profile_photo_path): ?>
                                                <img class="h-16 w-16 rounded-full"
                                                    src="<?php echo e(App\Helpers\Tools::StorageUrl($user->profile_photo_path)); ?>"
                                                    alt="">
                                            <?php else: ?>
                                                <img class="h-16 w-16 rounded-full"
                                                    src="<?php echo e(asset('img/user-def.png')); ?>" alt="">
                                            <?php endif; ?>

                                            <div>
                                                <h3
                                                    class="text-base font-semibold leading-7 tracking-tight text-gray-900">
                                                    <?php echo e($user->name); ?></h3>
                                                <p class="text-sm font-semibold leading-6 text-indigo-600">
                                                    <?php echo e($user->email); ?></p>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="container mx-auto mt-4 text-center">
                                    <div class="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
                                        role="status">
                                        <span
                                            class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...</span>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <hr class="mb-4 mt-4 font-semibold">
            
            <aside class="mt-4 mb-4 project-files">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-controller-files', ['project' => $project])->html();
} elseif ($_instance->childHasBeenRendered('l1831453185-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1831453185-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1831453185-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1831453185-0');
} else {
    $response = \Livewire\Livewire::mount('front.front-controller-files', ['project' => $project]);
    $html = $response->html();
    $_instance->logRenderedChild('l1831453185-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </aside>
            <aside class="mt-4 project-related">
                <h1 class="text-2xl md:text-xl-4 font-semibold mb-4 text-gray-600 text-center">
                    <?php echo e(__('Más proyectos de la Línea de Investigación ')); ?> <?php echo e($project->line->name); ?>

                </h1>
                <div class="mt-8 similar-project-list">
                    <?php if($similars && count($similars)): ?>
                        <ul class=" grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                            <?php $__currentLoopData = $similars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mb-4 w-70 md:w-80">
                                    <a href="<?php echo e(route('projects.show', $similar)); ?>">
                                        <?php if($similar->image): ?>
                                            <img class="p-4 mb-4 w-70 md:w-80 h-16-25"
                                                src="<?php echo e(App\Helpers\Tools::StorageUrl($similar->image->url)); ?>"
                                                alt="<?php echo e($similar->name); ?>">
                                        <?php else: ?>
                                            <img class="mb-4 w-70 md:w-80 h-16-25"
                                                src="<?php echo e(asset('img/notfound.svg')); ?>" alt="<?php echo e($similar->name); ?>">
                                        <?php endif; ?>
                                    </a>
                                    <div class="description text-gray-500 truncate-2">
                                        <?php echo strip_tags($similar->description); ?>

                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <div class="container mx-auto mt-4 text-center">
                            <div class="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"
                                role="status">
                                <span
                                    class="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Loading...</span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="mt-4 mb-4">
                    <?php if($similars && count($similars) && $similars->hasPages()): ?>
                        <?php echo e($similars->links()); ?>

                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </div>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.front-lines', [
        'same' => false,
        'title' => 'Algunas de nuestras Lineas de Investigación',
        'needButton' => true,
        'titleButton' => 'Conoce Nuestras lineas de Investigación',
    ])->html();
} elseif ($_instance->childHasBeenRendered('l1831453185-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l1831453185-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1831453185-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1831453185-1');
} else {
    $response = \Livewire\Livewire::mount('front.front-lines', [
        'same' => false,
        'title' => 'Algunas de nuestras Lineas de Investigación',
        'needButton' => true,
        'titleButton' => 'Conoce Nuestras lineas de Investigación',
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('l1831453185-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.front.front-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.front-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('url', null, []); ?> <?php echo e(asset('img/frontbanner/ucab.png')); ?> <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/project/project-show.blade.php ENDPATH**/ ?>