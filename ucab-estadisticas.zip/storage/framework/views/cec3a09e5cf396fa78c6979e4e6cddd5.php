<div wire:init='loadAnswerIndividual'>
    <div
        class="border border-gray-300 mb-6 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
        <div class="px-6 py-4">
            <?php if($quizUsers && count($quizUsers) && $quizUsers->hasPages()): ?>
                <div class="flex items-center justify-between mx-6">
                    <div class="mr-2">
                        <span class="mr-2">Ir a la Respuesta:</span>
                        <input wire:model="pageAux" type="number" min="1" max="<?php echo e($quizUsers->lastPage()); ?>"
                            class="border rounded px-2 py-1">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'gotoAnswerIndividual()','class' => 'ml-2 bg-blue-500 disabled:opacity-25']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'gotoAnswerIndividual()','class' => 'ml-2 bg-blue-500 disabled:opacity-25']); ?>
                            Ir
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>
                    <div>
                        <div class="mr-2 ">
                            <span class="mr-2">Respuesta <?php echo e($answerIndividualPage); ?> de </span>
                            <span class="mr-2"><?php echo e($quizUsers->lastPage()); ?></span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if($quizUsers && count($quizUsers) == 0): ?>
        <tr>
            <td colspan="5" class="px-6 py-4 text-center">
                <div class="container mt-4 mb-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-loading-danger','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-loading-danger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('title', null, []); ?> Pagina no existe <?php $__env->endSlot(); ?>
                         <?php $__env->slot('subtitle', null, []); ?> Puedes volver en el siguiente botón <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['wire:click' => 'resetAnswerIndividualPage()','class' => 'ml-2 bg-blue-500 disabled:opacity-25']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'resetAnswerIndividualPage()','class' => 'ml-2 bg-blue-500 disabled:opacity-25']); ?>
                                Resetear
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?> <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </td>
        </tr>
    <?php elseif($quizUsers && count($quizUsers)): ?>
        <?php $__currentLoopData = $quizUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quizUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="container border-t-3 border-blue-500 mt-4 mb-6 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
                <div class="px-6 py-4">
                    <div class="mt-4 text-sm text-gray-600 dark:text-gray-400">
                        <div class="container mt-4">
                            <div class="w-full form-control input-quiz border rounded-md p-2 overflow-hidden text-3xl">
                                <?php echo e($quizUser->quiz->name); ?>

                            </div>
                        </div>
                        <div class="container mt-4">
                            <div class="w-full form-control input-quiz border rounded-md p-2 overflow-hidden">
                                <?php echo e($quizUser->quiz->description); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = \App\Models\Answer::where('quiz_user_id', $quizUser->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($question = App\Models\Question::find($answer->question_id)): ?>
                    <div
                        class="border border-gray-300 mb-6 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
                        <div class="px-6 py-4">
                            <?php echo e($question->name); ?>

                        </div>
                        <?php if($question->typequestion == 1): ?>
                            <div class="container mt-4 mb-8">
                                <div class="w-full form-control input-quiz border rounded-md p-2 overflow-hidden">
                                    <?php echo e($answer->answer); ?>

                                </div>
                            </div>
                        <?php elseif($question->typequestion == 2): ?>
                            <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center container mt-4 mb-8">
                                    <input disabled id="default-radio-<?php echo e($question->id); ?>-<?php echo e($choice->id); ?>"
                                        type="radio" <?php if($choice->value == $answer->answer): ?> checked <?php endif; ?>
                                        value="<?php echo e($choice->value); ?>" name="question-radio-<?php echo e($question->id); ?>"
                                        class="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                    <label for="default-radio-<?php echo e($question->id); ?>-<?php echo e($choice->id); ?>"
                                        class="ml-2 dark:text-gray-300"><?php echo e($choice->value); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div
                        class="border border-gray-300 mb-6 mt-4 bg-white dark:bg-gray-800 rounded-lg overflow-hidden transform sm:w-full">
                        <div class="px-6 py-4">
                            Pregunta eliminada.
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\ucab-estadisticas\resources\views/livewire/answer/individual/answer-individual.blade.php ENDPATH**/ ?>