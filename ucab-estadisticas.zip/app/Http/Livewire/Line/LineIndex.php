<?php

namespace App\Http\Livewire\Line;

use Livewire\Component;

class LineIndex extends Component
{
    public function render()
    {
        return view('livewire.line.line-index');
    }
}
