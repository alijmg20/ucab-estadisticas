function alert(title, message){
    Swal.fire(
        title,
        message,
        'success'
    )
}

function dangerAlert(component,funcion,variable){

}
