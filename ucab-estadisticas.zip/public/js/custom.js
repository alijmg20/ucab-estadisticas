function alert(title, message){
    Swal.fire(
        title,
        message,
        'success'
    )
}